-- P07.sql
USE practice;

CREATE TABLE dt_demo2 AS SELECT * FROM lecture.dt_demo;

SELECT * FROM dt_demo2;

-- FROM dt_demo; -> Error. From dt_demo2;

-- 종합 정보 표시
-- id
-- name
-- 닉네임 (NULL -> '미설정')
-- 출생년도 (19xx년생)
-- 나이 (TIMESTAMPDIFF 로 나이만 표시)
-- 점수 (소수 1자리 반올림, NULL -> 0)
-- 등급 (A >= 90 / B >= 80 / C >= 70 / D)
-- 상태 (is_active 가 1 이면 '활성' / 0 '비활성')
-- 연령대 (청년 < 30 < 청장년 < 50 < 장년)

-- 내가 쓴 답
SELECT
	id,
	name,
    nickname,
    IFNULL(nickname, '미설정'),
	birth AS 원본,
    DATE_FORMAT(birth, '%Y년생') AS 한국식 ,
    TIMESTAMPDIFF(YEAR, birth, CURDATE()) AS 나이,
    CASE
		WHEN score >= 90 THEN 'A'
        WHEN score >= 80 THEN 'B'
        WHEN score >= 70 THEN 'C'
        ELSE 'D'
	END AS 학점,
	CASE
		WHEN 나이 > 50 THEN '장년'
        WHEN 나이 > 30 THEN '청장년'
        ELSE '청년'
	END AS 연령대,
	ROUND(score, 1) AS 소수1반올림,
    IFNULL(score, 0) AS 점수,
    IF(is_active = 1, '활성', '비활성')

FROM dt_demo2;

-- 종합 정보 표시 (정답)
SELECT
	id, -- id
	name, -- name
    -- 닉네임 (NULL -> '미설정')
	IFNULL(nickname, '미설정') AS 닉네임,
	-- 출생년도 (19xx년생)
    DATE_FORMAT(birth, '%Y년생') AS 출생년도,
	-- 나이 (TIMESTAMPDIFF 로 나이만 표시)
    TIMESTAMPDIFF(YEAR, birth, CURDATE()) AS 나이,
	-- 점수 (소수 1자리 반올림, Null -> 0)
    COALESCE(ROUND(score, 1), 0) AS 점수,
    IF(score IS NOT NULL, ROUND(score, 1), 0)AS 점수,
	-- 등급 (A >= 90 / B >= 80 / C >= 70 / D)
    CASE
		WHEN score >= 90 THEN 'A'
        WHEN score >= 80 THEN 'B'
        WHEN score >= 70 THEN 'C'
        ELSE 'D'
	END AS 등급,
	-- 상태 (is_active 가 1 이면 '활성' / 0 '비활성')
	IF(is_active=1, '활성', '비활성') AS 상태,
	-- 연령대 (청년 < 30 < 청장년 < 50 < 장년)
	CASE
		WHEN TIMESTAMPDIFF(YEAR, birth, CURDATE()) < 30 THEN '청년'
        WHEN TIMESTAMPDIFF(YEAR, birth, CURDATE()) < 50 THEN '청년'
		ELSE '장년'
    END AS 연령대
FROM dt_demo2;