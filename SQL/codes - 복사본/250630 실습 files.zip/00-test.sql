-- 00-test.sql

-- ctrl + Enter

SELECT version ();